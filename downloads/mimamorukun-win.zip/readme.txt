This is a tiny sample ZIP for testing downloads on GitHub Pages.
